var style = document.createElement('style');
style.setAttribute("id", "multiselect_dropdown_styles");
style.innerHTML = `
.multiselect-dropdown {
  display: inline-block;
  background-color: white;
  position: relative;
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: left 1vw center;
  background-size: 16px 16px;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  padding: .375rem .75rem .375rem 2.25rem;
}

.multiselect-dropdown span.optext,
.multiselect-dropdown span.placeholder {
  display: inline-block;
}

.multiselect-dropdown span.placeholder {
  margin-right: 20px;
}

.multiselect-dropdown span.optext {
  background-color: transparent;
  border-bottom: solid 4px rgb(67, 94, 190);
  padding: 5px 10px;
  margin: 0px 5px;
  float: right;
}

.multiselect-dropdown span.optext .optdel {
  float: left;
  font-size: 0.9em;
  cursor: pointer;
  color: rgb(181, 45, 45);
  padding-right: 0.5vw;
}

.multiselect-dropdown span.optext .optdel:hover {
  color: rgb(255, 0, 0);
}

.multiselect-dropdown span.placeholder {
  color: #ced4da;
}

.multiselect-dropdown-list-wrapper {
  box-shadow: gray 0 3px 8px;
  z-index: 100;
  border-radius: 10px;
  border: solid 1px #ced4da;
  display: none;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  background: white;
}

.multiselect-dropdown-list-wrapper .multiselect-dropdown-search {
  margin-bottom: 10px;
  margin-top: 0px;
}

.multiselect-dropdown-list {
  overflow-y: auto;
  overflow-x: hidden;
}

.multiselect-dropdown-list div {
  display: flex;
  flex-flow: row nowrap;
  justify-content: space-between;
  align-items: center;
  padding: 5px 25px;
  margin: 0 1vw;
}

.multiselect-dropdown-list input {
  width: 20px;
  height: 20px;
}

.multiselect-dropdown-list div.checked {
  border-right: 5px solid rgb(67, 94, 190);
  color: rgb(67, 94, 190);
  font-weight: bold;
  margin: 1vh 2vw;
}

.multiselect-dropdown-list div:hover {
  background-color: rgb(240, 241, 245);
}

.multiselect-dropdown span.maxselected {
  width: auto;
}

.multiselect-dropdown-all-selector {
  border-bottom: solid 1px #999;
}
`;
document.head.appendChild(style);

function MultiselectDropdown(options) {
    var config = {
        search: true,
        height: '30vh',
        width: '100%',
        minHeight: '120px',
        placeholder: 'انتخاب نمایید',
        txtSelected: 'مورد انتخاب شده',
        txtAll: 'انتخاب همه',
        txtRemove: 'حذف',
        txtSearch: 'جستجو',
        ...options
    };
    function newEl(tag, attrs) {
        var e = document.createElement(tag);
        if (attrs !== undefined) Object.keys(attrs).forEach(k => {
            if (k === 'class') { Array.isArray(attrs[k]) ? attrs[k].forEach(o => o !== '' ? e.classList.add(o) : 0) : (attrs[k] !== '' ? e.classList.add(attrs[k]) : 0) }
            else if (k === 'style') {
                Object.keys(attrs[k]).forEach(ks => {
                    e.style[ks] = attrs[k][ks];
                });
            }
            else if (k === 'text') { attrs[k] === '' ? e.innerHTML = '&nbsp;' : e.innerText = attrs[k] }
            else e[k] = attrs[k];
        });
        return e;
    }


    document.querySelectorAll("select[multiple]").forEach((el, k) => {

        var div = newEl('div', { class: 'multiselect-dropdown', style: { width: config.width, padding: config.style?.padding ?? '' } });
        el.style.display = 'none';
        el.parentNode.insertBefore(div, el.nextSibling);
        var listWrap = newEl('div', { class: 'multiselect-dropdown-list-wrapper' });
        var list = newEl('div', { class: 'multiselect-dropdown-list', style: { height: config.height, minHeight: config.minHeight } });
        var search = newEl('input', { class: ['multiselect-dropdown-search'].concat([config.searchInput?.class ?? 'form-control']), style: { width: '100%', display: el.attributes['multiselect-search']?.value === 'true' ? 'block' : 'none' }, placeholder: config.txtSearch });
        listWrap.appendChild(search);
        div.appendChild(listWrap);
        listWrap.appendChild(list);

        el.loadOptions = () => {
            list.innerHTML = '';

            if (el.attributes['multiselect-select-all']?.value == 'true') {
                var op = newEl('div', { class: 'multiselect-dropdown-all-selector' })
                op.appendChild(newEl('label', { text: config.txtAll }));
                var ic = newEl('input', { type: 'checkbox' });
                op.appendChild(ic);

                op.addEventListener('click', () => {
                    op.classList.toggle('checked');
                    op.querySelector("input").checked = !op.querySelector("input").checked;

                    var ch = op.querySelector("input").checked;
                    list.querySelectorAll(":scope > div:not(.multiselect-dropdown-all-selector)")
                        .forEach(i => {
                            if (i.style.display !== 'none') {
                                i.querySelector("input").checked = ch;
                                i.optEl.selected = ch;
                                if (ch == true) {
                                    list.querySelectorAll(":scope > div:not(.multiselect-dropdown-all-selector)")
                                        .forEach(i => { if (!i.classList.contains('checked')) { i.classList.toggle('checked'); } });
                                }
                                else {
                                    list.querySelectorAll(":scope > div:not(.multiselect-dropdown-all-selector)")
                                        .forEach(i => { if (i.classList.contains('checked')) { i.classList.toggle('checked'); } });
                                }
                            }
                        });


                    el.dispatchEvent(new Event('change'));
                });
                ic.addEventListener('click', (ev) => {
                    ic.checked = !ic.checked;
                });

                list.appendChild(op);
            }

            Array.from(el.options).map(o => {
                var op = newEl('div', { class: o.selected ? 'checked' : '', optEl: o })
                op.appendChild(newEl('label', { text: o.text }));
                var ic = newEl('input', { type: 'checkbox', checked: o.selected });
                op.appendChild(ic);

                op.addEventListener('click', () => {
                    op.classList.toggle('checked');
                    op.querySelector("input").checked = !op.querySelector("input").checked;
                    op.optEl.selected = !!!op.optEl.selected;
                    el.dispatchEvent(new Event('change'));
                });
                ic.addEventListener('click', (ev) => {
                    ic.checked = !ic.checked;
                });
                o.listitemEl = op;
                list.appendChild(op);
            });
            div.listEl = listWrap;

            div.refresh = () => {
                div.querySelectorAll('span.optext, span.placeholder').forEach(t => div.removeChild(t));
                var sels = Array.from(el.selectedOptions);
                if (sels.length > (el.attributes['multiselect-max-items']?.value ?? 5)) {
                    div.appendChild(newEl('span', { class: ['optext', 'maxselected'], text: sels.length + ' ' + config.txtSelected }));
                }
                else {
                    sels.map(x => {
                        var c = newEl('span', { class: 'optext', text: x.text, srcOption: x });
                        if ((el.attributes['multiselect-hide-x']?.value !== 'true'))
                            c.appendChild(newEl('span', { class: 'optdel', text: 'x', title: config.txtRemove, onclick: (ev) => { c.srcOption.listitemEl.dispatchEvent(new Event('click')); div.refresh(); ev.stopPropagation(); } }));

                        div.appendChild(c);
                    });
                }
                if (0 == el.selectedOptions.length) div.appendChild(newEl('span', { class: 'placeholder', text: el.attributes['placeholder']?.value ?? config.placeholder }));
            };
            div.refresh();
        }
        el.loadOptions();

        search.addEventListener('input', () => {
            list.querySelectorAll(":scope div:not(.multiselect-dropdown-all-selector)").forEach(d => {
                var txt = d.querySelector("label").innerText.toUpperCase();
                d.style.display = txt.includes(search.value.toUpperCase()) ? 'flex' : 'none';
            });
        });

        div.addEventListener('click', () => {
            div.listEl.style.display = 'block';
            search.focus();
            search.select();
        });

        document.addEventListener('click', function (event) {
            if (!div.contains(event.target)) {
                listWrap.style.display = 'none';
                div.refresh();
            }
        });
    });
}

window.addEventListener('load', () => {
    MultiselectDropdown(window.MultiselectDropdownOptions);
});